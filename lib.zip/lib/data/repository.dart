import 'dart:developer';

import 'package:flutter_iste/bloc/bloc_exports.dart';

import '../../models/task.dart';

class TasksRepository {
  List<Task> allTasks = [];

  List<Task> addTask(Task task) {
    allTasks.add(task);
    log('seia: $task');
    return allTasks;
  }

  // List<Todo> updateTodoState(bool isCompleted, String id) {
  //   for (Todo element in todoList) {
  //     if (element.todoId == id) {
  //       element.isCompleted = isCompleted;
  //     }
  //   }
  //   return todoList;
  // }
  List<Task> updateTask(Task task) {
    if (task.isDone == false) {
      // var taskIndex = allTasks.indexOf(task);
      allTasks.remove(task);
      // ..insert(taskIndex, task.copyWith(isDone: true));
      allTasks.add(task.copyWith(isDone: true));
    } else {
      allTasks.remove(task);
      allTasks.add(task.copyWith(isDone: false));
    }
    return allTasks;
  }

  List<Task> deleteTask(task) {
    allTasks.remove(task);
    return allTasks;
  }

  List<Task> removeTask(task) {
    allTasks.remove(task);
    allTasks.add(task.copyWith(isDeleted: true));
    return allTasks;
  }

  List<Task> markFavoriteOrUnfavoriteTask(task) {
    var taskIndex = allTasks.indexOf(task);
    if (task.isFavorite == false) {
      allTasks.remove(task);
      allTasks.insert(0, task.copyWith(isFavorite: true));
    } else {
      allTasks.remove(task);
      allTasks.insert(0, task.copyWith(isFavorite: false));
    }
    return allTasks;
  }

  List<Task> editTask(oldtask, newtask) {
    if (oldtask.isFavorite == true) {
      allTasks.remove(oldtask);
      allTasks.insert(0, newtask);
    }
    allTasks.remove(oldtask);
    allTasks.insert(0, newtask);
    return allTasks;
  }

  List<Task> restoreTask(Task task) {
    allTasks.remove(task);
    allTasks.insert(
        0,
        task.copyWith(
          isDeleted: false,
          isDone: task.isDone,
          isFavorite: task.isFavorite,
        ));
    return allTasks;
  }

  List<Task> deleteAllTasks() {
    for (Task t in allTasks) {
      if (t.isDeleted == true) {
        allTasks.remove(t);
      }
    }
    // allTasks.clear();
    return allTasks;
  }

  //
  //
  //
  //
  //
  //
  //
  // List<Task> pendingTasks = [];
  // List<Task> completedTasks = [];
  // List<Task> favoriteTasks = [];
  // List<Task> removedTasks = [];

  // List<Task>? pendingTasks;
  // List<Task>? completedTasks;
  // List<Task>? favoriteTasks;
  // List<Task>? removedTasks;

  // Map<String, dynamic> allTasks = {
  //   'pendingTasks': pendingTasks.map((e) => e.toMap()).toList(),
  //   'completedTasks': {},
  //   'favoriteTasks': {},
  //   'removedTasks': {},
  // };

// // moi
//   // TasksState addTask(Task task) {
//   // Map<String, dynamic> addTask(Task task) {
//   void addTask(Task task) {
//     // print('\n\n\n addd\n\n\n');
//     // print(task);
//     // print('\n\n\n addd\n\n\n');
//     pendingTasks
//         .add(task.copyWith(isDeleted: false, isFavorite: false, isDone: false));

//     // print(pendingTasks);
//     // removedTasks: state.removedTasks,
//     // favoriteTasks: state.favoriteTasks,
//     // completedTasks: state.completedTasks,
//     // return TasksLoaded(
//     //     pendingTasks: pendingTasks,
//     //     completedTasks: completedTasks,
//     //     favoriteTasks: favoriteTasks,
//     //     removedTasks: removedTasks);
//   }

//   void updateTask(Task task) {
//     if (task.isDone == false) {
//       if (task.isFavorite == false) {
//         pendingTasks.remove(task);
//         completedTasks.add(task.copyWith(isDone: true));
//         // completedTasks.insert(0, task.copyWith(isDone: true));
//       } else {
//         var taskIndex = favoriteTasks.indexOf(task);
//         pendingTasks.remove(task);
//         completedTasks.add(task.copyWith(isDone: true, isFavorite: true));
//         // completedTasks.insert(0, task.copyWith(isDone: true));
//         favoriteTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isDone: true, isFavorite: true));
//       }
//     } else {
//       if (task.isFavorite == false) {
//         completedTasks.remove(task);
//         pendingTasks.add(task.copyWith(isDone: false, isFavorite: false));
//       } else {
//         var taskIndex = favoriteTasks.indexOf(task);
//         completedTasks.remove(task);
//         pendingTasks.insert(0, task.copyWith(isDone: false, isFavorite: true));
//         favoriteTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isDone: false, isFavorite: true));
//       }
//     }
//   }

//   void deleteTask(task) {
//     removedTasks.remove(task);
//   }

//   void removeTask(task) {
//     pendingTasks.remove(task);
//     completedTasks.remove(task);
//     favoriteTasks.remove(task);
//     removedTasks.add(task.copyWith(isDeleted: true));
//   }

//   void markFavoriteOrUnfavoriteTask(task) {
//     if (task.isDone == false) {
//       if (task.isFavorite == false) {
//         var taskIndex = pendingTasks.indexOf(task);
//         pendingTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isFavorite: true, isDone: false));
//         favoriteTasks.add(
//           task.copyWith(
//             isFavorite: true,
//             isDeleted: false,
//             isDone: false,
//           ),
//         );
//       } else {
//         var taskIndex = pendingTasks.indexOf(task);
//         pendingTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isFavorite: false));
//         favoriteTasks = List.from(pendingTasks)..remove(task);
//       }
//     } else {
//       if (task.isFavorite == false) {
//         var taskIndex = completedTasks.indexOf(task);
//         completedTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isFavorite: true));
//         favoriteTasks.add(
//           task.copyWith(
//             isFavorite: true,
//             isDeleted: false,
//             isDone: true,
//           ),
//         );
//       } else {
//         var taskIndex = completedTasks.indexOf(task);
//         completedTasks
//           ..remove(task)
//           ..insert(taskIndex, task.copyWith(isFavorite: false));
//         favoriteTasks.remove(task);
//       }
//     }
//   }

//   void editTask(oldtask, newtask) {
//     if (oldtask.isFavorite == true) {
//       favoriteTasks
//         ..remove(oldtask)
//         ..insert(0, newtask);
//     }
//     if (oldtask.isDone == true) {
//       completedTasks.remove(oldtask);
//     }
//     pendingTasks
//       ..remove(oldtask)
//       ..insert(0, newtask);
//   }

//   void restoreTask(task) {
//     removedTasks.remove(task);
//     pendingTasks.insert(
//         0,
//         task.copyWith(
//           isDeleted: false,
//           isDone: false,
//           isFavorite: false,
//         ));
//   }

//   void deleteAllTasks() {
//     removedTasks.clear();
//   }

  // List<Task> getPendingTasks() {
  //   return pendingTasks;
  // }

  // List<Task> getCompletedTasks() {
  //   return completedTasks;
  // }

  // List<Task> getRemovedTasks() {
  //   return removedTasks;
  // }

  // List<Task> getFavoriteTasks() {
  //   return favoriteTasks;
  // }
}
